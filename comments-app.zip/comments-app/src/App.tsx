import { Comments } from "./features/comments";

function App() {
  return <Comments />;
}

export default App;
