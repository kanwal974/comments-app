import { useEffect, useState } from "react";
import { IComment } from "../interfaces";
import { Comment } from "./comment";
export const Comments = () => {
  const [comments, setComments] = useState<IComment[]>([]);
  const [comment, setComment] = useState(" ");
  useEffect(() => {
    fetch("http://localhost:3031/comments")
      .then((response) => response.json())
      .then((data) => setComments(data as IComment[]));
  }, []);

  return (
    <>
      {comments.map((comment) => (
        <Comment {...comment} />
      ))}
      <input
        placeholder="Write your comment"
        onChange={(e) => setComment(e.target.value)}
      />
    </>
  );
};
