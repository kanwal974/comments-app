import { IComment } from "../interfaces";

interface CommentProps extends IComment {}

export const Comment = ({ id, name, comment, profileImg }: CommentProps) => {
  return (
    <div key={id} className="d-flex">
      <img src={profileImg} alt={name} height={40} />
      <div className="ms-2">
        <h5>{name}</h5>
        <p>{comment}</p>
      </div>
    </div>
  );
};
